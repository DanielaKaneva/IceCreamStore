package decorator;

public class ChocolateIceCream implements IceCream {

    @Override
    public void create() {
        System.out.println("The client wants a chooclate ice cream");
    }

    @Override
    public void eat() {
    }
}
