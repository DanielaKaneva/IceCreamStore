package decorator;

import java.util.Random;

public class CreateAndDecorateDecorator extends IceCreamDecorator {

    private String place;
    Random random = new Random();
    private boolean decoration;

    public CreateAndDecorateDecorator(IceCream decoratedIceCream, String place) {
        super(decoratedIceCream);
        this.place = place;
    }

    @Override
    public void create() {
        System.out.println("A new client enters the store");
        super.create();
        this.decorateIceCream();
    }

    @Override
    public void eat() {
        super.eat();
        this.eatIceCream();
    }

    private void decorateIceCream() {
        decoration = random.nextBoolean();
        if (decoration) {
            System.out.println("The client wants the ice cream to be decorated with chocolate sticks");
        } else {
            System.out.println("The client wants the ice cream to be decorated with chocolate glaze");
        }
    }

    private void eatIceCream() {
        System.out.println("The clients eats the ice cream " + this.place);
    }
}