package decorator;

public abstract class IceCreamDecorator implements IceCream {

    protected IceCream decoratedIceCream;

    public IceCreamDecorator(IceCream decoratedIceCream) {
        this.decoratedIceCream = decoratedIceCream;
    }

    @Override
    public void create() {
        this.decoratedIceCream.create();
    }

    @Override
    public void eat() {
        this.decoratedIceCream.eat();
    }
}
