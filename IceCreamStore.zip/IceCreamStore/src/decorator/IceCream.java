package decorator;

public interface IceCream {
    void create();
    void eat();
}
