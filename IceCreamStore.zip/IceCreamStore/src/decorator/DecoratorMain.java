package decorator;

public class DecoratorMain {
    public static void main(String[] args) {

        IceCream chocolate = new ChocolateIceCream();
        chocolate = new CreateAndDecorateDecorator(chocolate, "in the park");
        chocolate.create();
        chocolate.eat();

        IceCream strawberry = new StrawberryIceCream();
        strawberry = new CreateAndDecorateDecorator(strawberry, "on the beach");
        strawberry.create();
        strawberry.eat();

        IceCream vanilla = new VanillaIceCream();
        vanilla = new CreateAndDecorateDecorator(vanilla, "in the store");
        vanilla.create();
        vanilla.eat();
    }
}
