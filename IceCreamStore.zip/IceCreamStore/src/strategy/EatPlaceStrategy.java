package strategy;

public interface EatPlaceStrategy {
    void eat(String type);
}
