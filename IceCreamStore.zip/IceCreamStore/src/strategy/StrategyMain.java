package strategy;

public class StrategyMain {
    public static void main(String[] args) {
        IceCream iceCream = new IceCream();

        iceCream.setEatPlaceStrategy(new BeachPlaceStrategy());
        iceCream.createAndEatIceCream("vanilla");

        iceCream.setEatPlaceStrategy(new ParkPlaceStrategy());
        iceCream.createAndEatIceCream("strawberry");

        iceCream.setEatPlaceStrategy(new StorePlaceStrategy());
        iceCream.createAndEatIceCream("chocolate");
    }
}