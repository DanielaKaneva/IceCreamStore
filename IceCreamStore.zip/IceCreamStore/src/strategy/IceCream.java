package strategy;

import java.util.Random;

public class IceCream {
    private EatPlaceStrategy eatPlaceStrategy;
    Random random = new Random();
    private boolean decoration;

    public void setEatPlaceStrategy(EatPlaceStrategy eatPlaceStrategy) {
        this.eatPlaceStrategy = eatPlaceStrategy;
    }

    public void createAndEatIceCream(String type) {
        decoration = random.nextBoolean();

        System.out.println("A new client enters the store");
        System.out.println("The client wants a " + type + " ice cream");
        if (decoration) {
            System.out.println("The client wants the ice cream to be decorated with chocolate glaze");
        } else {
            System.out.println("The client wants the ice cream to be decorated with chocolate sticks");
        }
        eatPlaceStrategy.eat(type);
    }
}
