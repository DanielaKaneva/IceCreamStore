package strategy;

public class ParkPlaceStrategy implements EatPlaceStrategy {
    @Override
    public void eat(String type) {
        System.out.println("The client eats the ice cream in the park");
    }
}
