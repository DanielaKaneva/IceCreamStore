package strategy;

public class BeachPlaceStrategy implements EatPlaceStrategy {
    @Override
    public void eat(String type) {
        System.out.println("The client eats the ice cream on the beach");
    }
}
