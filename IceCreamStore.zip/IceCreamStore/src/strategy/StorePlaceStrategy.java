package strategy;

public class StorePlaceStrategy implements EatPlaceStrategy {
    @Override
    public void eat(String type) {
        System.out.println("The client eats the ice cream in the store");
    }
}
