package singleton;

public class IceCream {

    private static IceCream instance;

    private IceCream() {}

    public static IceCream getInstance() {
        if(instance == null) {
            instance = new IceCream();
        }
        return instance;
    }

    public void createIceCream(String type, String place) {
        String[] iceCreamDecorations = {"chocolate glaze", "chocolate sticks"};
        String iceCreamDecoration = iceCreamDecorations[(int)(Math.random() * iceCreamDecorations.length)];

        System.out.println("A new client is entering the store");
        System.out.println("The client wants a " + type + " ice cream");
        System.out.println("The client wants the ice cream to be decorated with " + iceCreamDecoration);
        System.out.println("The client is eating the ice cream " + place);
    }
}
