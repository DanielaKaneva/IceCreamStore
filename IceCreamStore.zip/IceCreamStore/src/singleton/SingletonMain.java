package singleton;

public class SingletonMain {
    public static void main(String[] args) {
        IceCream iceCream = IceCream.getInstance();

        iceCream.createIceCream("vanilla", "in the store");
        iceCream.createIceCream("chocolate", "in the park");
        iceCream.createIceCream("strawberry", "on the beach");
    }
}