package factory;

public class PlaceTypeConstants {
    public static final String BEACH = "BEACH";
    public static final String PARK = "PARK";
    public static final String STORE = "STORE";
    private PlaceTypeConstants(){}
}
