package factory;

public class BeachPlace extends Place {
    @Override
    public void create() {
        System.out.println("The client is eating the ice cream on the beach");
    }
}
