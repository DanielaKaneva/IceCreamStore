package factory;

public class ParkPlace extends Place {
    @Override
    public void create() {
        System.out.println("The client is eating the ice cream in the park");
    }
}
