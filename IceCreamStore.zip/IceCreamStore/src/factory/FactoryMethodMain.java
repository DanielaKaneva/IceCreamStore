package factory;

public class FactoryMethodMain {
    public static void main(String[] args) {
        Store icecream = new IceCreamFactory();
        Store place = new PlaceFactory();
        IceCream chocolateIceCream = icecream.produceIceCream(IceCreamTypeConstants.CHOCOLATE);
        Place beachPlace = place.producePlace(PlaceTypeConstants.BEACH);
        IceCream vanillaIceCream = icecream.produceIceCream(IceCreamTypeConstants.VANILLA);
        Place parkPlace = place.producePlace(PlaceTypeConstants.PARK);
        IceCream strawberryIceCream = icecream.produceIceCream(IceCreamTypeConstants.STRAWBERRY);
        Place storePlace = place.producePlace(PlaceTypeConstants.STORE);
    }
}
