package factory;

public class StrawberryIceCream extends IceCream {
    @Override
    public void create() {
        System.out.println("The client wants a strawberry ice cream");
    }
}
