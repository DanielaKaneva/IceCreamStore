package factory;

public class IceCreamFactory extends Store {

    @Override
    public IceCream createIceCream(String type) {

        System.out.println("A new client enters the store");

        if(type.equals(IceCreamTypeConstants.VANILLA)) {
            return new VanillaIceCream();
        }
        if(type.equals(IceCreamTypeConstants.STRAWBERRY)) {
            return new StrawberryIceCream();
        }
        if(type.equals(IceCreamTypeConstants.CHOCOLATE)) {
            return new ChocolateIceCream();
        }
        System.out.println("Unknown ice cream");
        return null;
    }

    @Override
    public Place createPlace(String type) {
        return null;
    }
}
