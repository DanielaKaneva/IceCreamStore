package factory;

public class PlaceFactory extends Store {

    @Override
    public IceCream createIceCream(String type) {
        return null;
    }

    @Override
    public Place createPlace(String type) {

        if(type.equals(PlaceTypeConstants.BEACH)) {
            return new BeachPlace();
        }
        if(type.equals(PlaceTypeConstants.STORE)) {
            return new StorePlace();
        }
        if(type.equals(PlaceTypeConstants.PARK)) {
            return new ParkPlace();
        }
        System.out.println("Unknown place");
        return null;
    }
}
