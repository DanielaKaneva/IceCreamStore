package factory;

public abstract class Store {

    public abstract IceCream createIceCream(String type);

    public abstract Place createPlace(String type);

    public IceCream produceIceCream(String type) {
        IceCream iceCreamType = createIceCream(type);
        iceCreamType.create();
        String[] iceCreamDecorations = {"chocolate glaze", "chocolate sticks"};
        String iceCreamDecoration = iceCreamDecorations[(int)(Math.random() * iceCreamDecorations.length)];
        System.out.println("The client wants the ice cream to be decorated with " + iceCreamDecoration);
        return iceCreamType;
    }

    public Place producePlace(String type) {
        Place placeType = createPlace(type);
        placeType.create();
        return placeType;
    }


}
