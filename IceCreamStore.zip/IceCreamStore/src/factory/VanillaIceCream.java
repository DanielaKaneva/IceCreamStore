package factory;

public class VanillaIceCream extends IceCream {
    @Override
    public void create() {
        System.out.println("The client wants a vanilla ice cream");
    }
}
