package factory;

public class IceCreamTypeConstants {
    public static final String CHOCOLATE = "CHOCOLATE";
    public static final String STRAWBERRY = "STRAWBERRY";
    public static final String VANILLA = "VANILLA";
    private IceCreamTypeConstants(){}
}
